<?php 

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once  PAYMONEY_WOOCOMMERCE_ADDON_DIR . 'src/Common/Paymoney_WoocommercePaymentGateway.php';

class Paymoney_RedirectUrls extends Paymoney_WoocommercePaymentGateway 
{
    public function paymoney_set_return_url( $paymoney_url )
    {
        $this->paymoney_return_url = $paymoney_url;
        return $this;
    }

    public function paymoney_get_return_url()
    {
        return $this->paymoney_return_url;
    }

    public function paymoney_set_cancel_url( $paymoney_url )
    {
        $this->paymoney_cancel_url = $paymoney_url;
        return $this;
    }

    public function paymoney_get_cancel_url()
    {
        return $this->paymoney_cancel_url;
    }
}