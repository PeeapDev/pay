<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once  PAYMONEY_WOOCOMMERCE_ADDON_DIR . 'src/Common/Paymoney_WoocommercePaymentGateway.php';

class Paymoney_Amount extends Paymoney_WoocommercePaymentGateway
{    
    public function paymoney_set_total( $paymoney_amount )
    {
        $this->paymoney_total_amount = $paymoney_amount;
        return $this;
    }

    public function paymoney_get_total()
    {
        return $this->paymoney_total_amount;
    }
    
    public function paymoney_set_currency( $paymoney_currency )
    {
        $this->paymoney_currency = $paymoney_currency;
        return $this;
    }

    public function paymoney_get_currency()
    {
        return $this->paymoney_currency;
    }
}