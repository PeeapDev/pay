<?php 

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once  PAYMONEY_WOOCOMMERCE_ADDON_DIR . 'src/Common/Paymoney_WoocommercePaymentGateway.php';


class Paymoney_Transaction extends Paymoney_WoocommercePaymentGateway 
{
    public function paymoney_set_amount( $paymoney_amount )
    {
        $this->paymoney_amount = $paymoney_amount;
        return $this;
    }

    public function paymoney_get_amount()
    {
        return $this->paymoney_amount;
    }

    public function paymoney_set_items( $paymoney_items )
    {
        $this->paymoney_items = $paymoney_items;
        return $this;
    }

    public function paymoney_get_items()
    {
        return $this->paymoney_items;
    }
}