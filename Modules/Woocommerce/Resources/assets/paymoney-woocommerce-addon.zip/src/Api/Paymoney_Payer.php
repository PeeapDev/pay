<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once  PAYMONEY_WOOCOMMERCE_ADDON_DIR . 'src/Common/Paymoney_WoocommercePaymentGateway.php' ;

class Paymoney_Payer extends Paymoney_WoocommercePaymentGateway 
{    
    public function paymoney_set_payment_method($paymoney_method)
    {
        $this->paymoney_payment_method = $paymoney_method;
        return $this;
    }

    public function paymoney_get_payment_method()
    {
        return $this->paymoney_payment_method;
    }
}